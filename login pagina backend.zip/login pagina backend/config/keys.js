dbPassword = "mongodb+srv://Kilroy763:TEST@projecttech-mt8t7.azure.mongodb.net/test?retryWrites=true&w=majority";

module.exports = {
    mongoURI: dbPassword
};

// link met de database