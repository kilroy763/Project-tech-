Ik heb dit gemaakt met behulp van de volgende video:
https://www.youtube.com/watch?v=6FOq4cUdH8k&t=2075s

Niks zat mee en ik kreeg niks aan de praat en heb daarom een volledige tutorial gevolgt. 
Voor de eindoplevering zal ik uiteraard de registratie meer naar een datingapp draaien alleen daar had ik nu geen tijd meer voor.

Ik heb een pagina gemaakt waarbij ingelogd kan worden nadat er geregistreerd is. de registratie wordt opgeslagen in de database.
Hierna worden enkele gegevens aangetoont in een overzicht
